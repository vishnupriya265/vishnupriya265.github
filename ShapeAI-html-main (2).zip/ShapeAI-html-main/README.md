# SHAPEAI WEB DEV BOOTCAMP

Hi I made this project during the 7 Days Free Bootcamp, conducted by <b> SHAPEAI </ b> .

The instructor during the session was Mr. Shaurya Sinha (a Data Analyst at Jio). I got to learn a lot during these 7 days and it was an amazing experience learning with SHAPEAI.

<br>I got to have hands on experience on:

<li>HTML

<li>CSS

<br>during these 7 days, and everything was explained from the very basics so that anyone with zero experience on programming can learn.

I enjoyed these 7 days, you can as well. To register for next free 7 days bootcamp, visit: www.shapeai.tech or follow SHAPEAI on:

<li><a href="https://in.linkedin.com/company/shapeai">LinkedIn</a> <li><a href="https://www.instagram.com/shape.ai/?hl=en">Instagram</a>

<li><a href="https://www.youtube.com/channel/UCTUvDLTW9meuDXWcbmISPdA">YouTu be</a>

<li><a href="https://github.com/shapeai">GitHub</a>
